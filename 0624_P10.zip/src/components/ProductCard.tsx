// ============================================================================
// ProductCard — 바자회 상품 카드 (BazaarPage 등에서 공통 사용)
//
// [변경 이력]
//   2026-06-24  [Task 2] Figma 리스트 카드 3-상태 1:1 재구현.
//               · 기본(1791:216) / 호버·찜안함(1791:194) / 호버·찜함(1791:411)
//               · full-bleed 정사각 이미지(aspect 1/1, bg #d7d7d7) + 모서리/보더/그림자 제거
//               · 호버 시 이미지 하단 액션바 [Add To Cart | 찜/이미 찜 함] 슬라이드 등장
//               · 찜 상태 → 본문에 초록 "찜" 뱃지 상시 노출(#beff9b) + 액션바 버튼 전환
//               · 본문 패딩 16/20/20/0(좌 0=Figma), 뱃지/제목/가격 14·20px Pretendard Regular
//               · add-to-cart=기존 cart API(qty 1), 찜=신규 useWishlist 훅
//               · 품절/저재고 등 필수 안전 동작 보존(품절 시 액션바 미노출)
//   2026-06-24  [모바일 최적화] 호버 액션바 버튼을 카드 폭 비례(container query)로 재설계.
//               · 고정 padding 16/32·font 16 → cqi+clamp 로 카드폭에 비례 축소(2열 모바일 안 넘침)
//               · 런타임 <style> 주입(ensureStyles) 제거 → 전역 index.css 클래스로 이관(공유/캐시)
//               · .pcard / .pcard-img / .pcard-actions / .pcard-btn 사용
//   2026-06-23  카테고리/브랜드 태그 칩(splitTagsByKind) — Task2 카드에서 제거됨(필터는 사이드바로 이관)
//
// [Figma SSOT] node 1791:216 / 1791:194 / 1791:411 (file ydfT0xP6nc83VxFd7GyEx4)
// ============================================================================

import { useState } from 'react';
import { Link } from 'react-router-dom';
import { getAvailableStock, isSoldOut, isNewProduct } from '@/lib/products';
import { BlurImage } from './BlurImage'; // ← 썸네일 lazy+블러업
import { addToCart } from '@/lib/cart'; // ← [2026-06-24] 카드 빠른 담기
import { signInWithMicrosoft } from '@/lib/auth'; // ← [2026-06-24] 비로그인 가드
import { useCurrentUser } from '@/hooks/useCurrentUser'; // ← [2026-06-24]
import { useWishlist } from '@/hooks/useWishlist'; // ← [2026-06-24] 찜 토글
import type { EsgProductRow } from '@/types/esg';

// 호버 액션바/카드 스타일은 전역 index.css(.pcard*)로 이관됨 (런타임 주입 제거).

interface ProductCardProps {
  product: EsgProductRow;
}

export function ProductCard({ product }: ProductCardProps) {
  const { currentUser } = useCurrentUser();
  const { wishlisted, toggle } = useWishlist(product.id); // ← [2026-06-24]

  const available = getAvailableStock(product);
  const soldOut = isSoldOut(product);

  const [adding, setAdding] = useState(false); // ← [2026-06-24] 담기 진행/완료 transient
  const [justAdded, setJustAdded] = useState(false);

  // 빠른 담기 — 카드는 Link이므로 버튼 클릭 시 네비게이션 차단
  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation(); // ← Link 이동 방지
    if (!currentUser) { signInWithMicrosoft().catch(console.error); return; }
    if (soldOut || adding) return;
    setAdding(true);
    try {
      await addToCart({ id: currentUser.id, email: currentUser.email }, product.id, 1); // notifyCartChanged 포함
      setJustAdded(true);
      window.setTimeout(() => setJustAdded(false), 1200); // ← 1.2s "담음!" 표시 후 복귀
    } catch (err) {
      console.error('[ProductCard] addToCart error:', err);
      alert(err instanceof Error ? err.message : '장바구니 추가에 실패했습니다.');
    } finally {
      setAdding(false);
    }
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation(); // ← Link 이동 방지
    toggle().catch(console.error);
  };

  return (
    <Link
      to={`/bazaar/${product.id}`}
      className="pcard"
      style={{
        opacity: soldOut ? 0.6 : 1, // ← 품절 시각 약화(필수 동작 보존, 동적값이라 인라인 유지)
      }}
    >
      {/* ── 이미지(정사각 full-bleed, 컨테이너 쿼리 기준) ── */}
      <div className="pcard-img">
        {product.thumbnail_url && (
          <div style={{ position: 'absolute', inset: 0 }}>
            <BlurImage url={product.thumbnail_url} width={680} />
          </div>
        )}

        {/* 품절 오버레이 — 품절 시 액션바 대신 노출 */}
        {soldOut && (
          <div
            style={{
              position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', fontWeight: 700, fontSize: 18, letterSpacing: 0.5,
            }}
          >
            품절
          </div>
        )}

        {/* 호버 액션바 [Add To Cart | 찜/이미 찜 함] — 카드폭 비례 버튼 (품절 시 미노출) */}
        {!soldOut && (
          <div className="pcard-actions">
            <button
              type="button"
              className="pcard-btn"
              onClick={handleAddToCart}
              disabled={adding}
              style={{
                background: '#000', color: '#fff', textTransform: 'capitalize',
              }}
            >
              {justAdded ? '담음!' : 'add to cart'}
            </button>
            <button
              type="button"
              className="pcard-btn"
              onClick={handleToggleWishlist}
              style={{
                background: wishlisted ? '#beff9b' : '#fff', color: '#111',
              }}
            >
              {wishlisted ? '이미 찜 함' : '찜'}
            </button>
          </div>
        )}
      </div>

      {/* ── 본문(좌 패딩 0 = Figma) ── */}
      <div
        style={{
          background: '#fff',
          padding: '16px 20px 20px 0', // ← Figma pt16 pr20 pb20 pl0
          display: 'flex', flexDirection: 'column',
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {/* 뱃지 행: [찜(상시, 찜한 경우)] [새 제품(is_new)] */}
          {(wishlisted || isNewProduct(product)) && (
            <div style={{ display: 'flex', gap: 4, alignItems: 'flex-start' }}>
              {wishlisted && (
                <span style={{
                  background: '#beff9b', color: '#111', fontSize: 14, lineHeight: 1.3,
                  padding: '4px 8px', whiteSpace: 'nowrap',
                }}>
                  찜
                </span>
              )}
              {isNewProduct(product) && (
                <span style={{
                  background: '#fff', color: '#000', border: '1px solid #000',
                  fontSize: 14, lineHeight: 1.3, padding: '4px 8px', whiteSpace: 'nowrap',
                  textTransform: 'capitalize',
                }}>
                  새 제품
                </span>
              )}
            </div>
          )}

          {/* 제목 + 가격 (Pretendard Regular 20px) */}
          <div style={{ display: 'flex', flexDirection: 'column', padding: '8px 0' }}>
            <p
              style={{
                margin: 0, fontSize: 20, lineHeight: 1.4, color: '#111',
                letterSpacing: '-0.2px',
                display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
                overflow: 'hidden',
              }}
            >
              {product.name}
            </p>
            <p style={{ margin: 0, fontSize: 20, lineHeight: 1.4, color: '#111', letterSpacing: '0.2px' }}>
              {product.price.toLocaleString()}원
            </p>
          </div>
        </div>

        {/* 저재고 안내(품절 임박) — Figma 미표기지만 필수 정보로 최소 노출 */}
        {!soldOut && available <= 5 && available > 0 && (
          <span style={{ marginTop: 4, fontSize: 12, color: '#ef4444', fontWeight: 600 }}>
            {available}개 남음
          </span>
        )}
      </div>
    </Link>
  );
}
