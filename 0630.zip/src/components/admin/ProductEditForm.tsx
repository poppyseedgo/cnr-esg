// ============================================================================
// ProductEditForm — 바자회 상품 편집 폼 (공통 컴포넌트)
//
// 사용처:
//   1. AdminProducts 카드 인라인 편집
//   2. BazaarProductPage 어드민 편집 모드
//
// 내부에서 updateProduct / deleteProduct 호출.
// 부모는 onSuccess / onCancel만 제공.
// ============================================================================

import { useState, useEffect } from 'react';
import { updateProduct, deleteProduct } from '@/lib/adminProducts';
import { pushNoteToLinkedIntake } from '@/lib/bazaarIntake'; // ← [2026-06-17] 상품 상세 → 검수 메모 밀어넣기
import { getAvailableStock } from '@/lib/products';
import { getProductTags, setProductTags, splitTagsByKind } from '@/lib/tags'; // ← [2026-06-23] 카테고리/브랜드 분리
import { TagInput } from '@/components/admin/TagInput'; // ← [2026-06-22] 태그 입력 UI
import { ThumbnailUploader, DetailImagesUploader } from '@/components/ImageUploader';
import { RichEditor } from '@/components/RichEditor';
import type { EsgProductRow, EsgProductStatus, EsgTagRow } from '@/types/esg'; // ← [2026-06-22] EsgTagRow

interface ProductEditFormProps {
  product: EsgProductRow;
  onSuccess: () => void;
  onCancel: () => void;
  /** 삭제 후 처리 (예: 페이지 이동) */
  onDeleted?: () => void;
  /** 삭제 버튼 표시 여부 (기본 true) */
  showDelete?: boolean;
  /** 현재 고정된 상품 수 (체크박스에 N/8 표시용, 선택) */   // ← [2026-06-17]
  pinnedCount?: number;
}

export function ProductEditForm({
  product,
  onSuccess,
  onCancel,
  onDeleted,
  showDelete = true,
  pinnedCount,                                                // ← [2026-06-17]
}: ProductEditFormProps) {
  const [busy, setBusy] = useState(false);
  const [pushing, setPushing] = useState(false); // ← [2026-06-17] 검수 메모로 밀어넣기 진행중

  // 상품 상세설명 → 연결된 검수 메모로 밀어넣기(덮어쓰기). 폼 저장과 별개로 즉시 반영.
  const pushDescToNote = async () => {
    if (
      !confirm(
        "현재 '상품 상세설명' 내용을 연결된 '검수 메모'에 덮어씁니다.\n" +
          '이 폼의 저장과는 별개로 즉시 반영됩니다.\n계속할까요?'
      )
    )
      return;
    setPushing(true);
    try {
      const ok = await pushNoteToLinkedIntake(product.id, description || '');
      alert(ok ? '검수 메모에 반영했습니다.' : '연결된 검수 항목이 없습니다.');
    } catch (e) {
      alert(e instanceof Error ? e.message : '반영 실패');
    } finally {
      setPushing(false);
    }
  };
  const [name, setName] = useState(product.name);
  const [description, setDescription] = useState(product.description ?? '');
  const [price, setPrice] = useState(product.price);
  const [stock, setStock] = useState(product.stock);
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(product.thumbnail_url);
  const [detailImages, setDetailImages] = useState<string[]>(product.detail_images ?? []);
  const [status, setStatus] = useState<EsgProductStatus>(product.status);
  const [sortOrder, setSortOrder] = useState(product.sort_order);
  const [isNew, setIsNew] = useState(product.is_new);                                  // ← [2026-06-09]
  const [isPinned, setIsPinned] = useState(product.is_pinned);                         // ← [2026-06-17] 상품 고정
  const [salePrice, setSalePrice] = useState<number | ''>(product.sale_price ?? '');   // ← [2026-06-09]

  // ── [2026-06-22 → 2026-06-23] 상품 태그(카테고리/브랜드 분리) ──────────────
  const [categoryTags, setCategoryTags] = useState<EsgTagRow[]>([]); // ← #유아용품 #식품
  const [brandTags, setBrandTags] = useState<EsgTagRow[]>([]);       // ← #나이키 #샤넬
  const [initialTagIds, setInitialTagIds] = useState<string[]>([]);
  useEffect(() => {
    let alive = true;
    getProductTags(product.id)
      .then((rows) => {
        if (!alive) return;
        const { categories, brands } = splitTagsByKind(rows); // ← [2026-06-23] 종류별 분리
        setCategoryTags(categories);
        setBrandTags(brands);
        setInitialTagIds(rows.map((t) => t.id));
      })
      .catch(() => {/* 태그 로드 실패는 조용히(빈 상태로 시작) */});
    return () => { alive = false; };
  }, [product.id]);

  // ← [2026-06-09] 세일 유효성/할인율 미리보기
  const saleActive = salePrice !== '' && salePrice >= 0 && salePrice < price;
  const discountPct = saleActive ? Math.round(((price - (salePrice as number)) / price) * 100) : null;

  // ← [2026-06-17] 고정 8개 도달 && 현재 미고정 → 새 고정 불가(체크박스 비활성)
  const pinFull = typeof pinnedCount === 'number' && pinnedCount >= 8 && !product.is_pinned;

  const save = async () => {
    if (!name.trim()) {
      alert('상품명을 입력해주세요.');
      return;
    }
    if (price < 0 || stock < 0) {
      alert('가격과 재고는 0 이상이어야 합니다.');
      return;
    }
    if (stock < product.reserved_stock) {
      const ok = confirm(
        `재고를 ${product.reserved_stock}개 미만으로 설정합니다. ` +
          `이미 선점된 주문(${product.reserved_stock}개)이 있어 데이터 정합성에 문제가 생길 수 있습니다.\n` +
          `계속하시겠습니까?`
      );
      if (!ok) return;
    }

    setBusy(true);
    try {
      const patch: Record<string, unknown> = {};
      if (name !== product.name) patch.name = name;
      if (description !== (product.description ?? '')) patch.description = description || null;
      if (price !== product.price) patch.price = price;
      if (stock !== product.stock) patch.stock = stock;
      if (thumbnailUrl !== product.thumbnail_url) patch.thumbnail_url = thumbnailUrl;
      if (JSON.stringify(detailImages) !== JSON.stringify(product.detail_images ?? [])) {
        patch.detail_images = detailImages;
      }
      if (status !== product.status) patch.status = status;
      if (sortOrder !== product.sort_order) patch.sort_order = sortOrder;
      // ← [2026-06-09] 새 상품 / 세일가 diff. 세일가는 정상가 미만일 때만 적용, 아니면 null.
      const nextSale = saleActive ? (salePrice as number) : null;
      if (isNew !== product.is_new) patch.is_new = isNew;
      if (isPinned !== product.is_pinned) patch.is_pinned = isPinned;   // ← [2026-06-17] 고정 diff
      if (nextSale !== product.sale_price) patch.sale_price = nextSale;

      // ← [2026-06-23] 카테고리+브랜드 합쳐서 변경 감지(정렬 후 비교). RPC는 patch와 별개로 호출.
      const allTags = [...categoryTags, ...brandTags];
      const curTagIds = allTags.map((t) => t.id).sort();
      const tagsChanged = JSON.stringify(curTagIds) !== JSON.stringify([...initialTagIds].sort());

      if (Object.keys(patch).length === 0 && !tagsChanged) {
        onCancel();
        return;
      }

      if (Object.keys(patch).length > 0) {
        await updateProduct(product.id, patch as never);
      }
      if (tagsChanged) {
        await setProductTags(product.id, allTags.map((t) => t.id)); // 원자적 교체(빈 배열=전체 해제)
      }
      onSuccess();
    } catch (e) {
      alert(e instanceof Error ? e.message : '저장 실패');
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async () => {
    const ok = confirm(
      `"${product.name}"을(를) 영구 삭제합니다. 되돌릴 수 없습니다.\n\n` +
        `완료된 주문·Q&A·진행 중 주문이 있으면 삭제할 수 없습니다. 이 경우 "숨김" 처리하세요.\n계속하시겠습니까?` // ← [정책㉠] 문구 정정
    );
    if (!ok) return;
    setBusy(true);
    try {
      await deleteProduct(product.id);
      onDeleted ? onDeleted() : onSuccess();
    } catch (e) {
      alert(e instanceof Error ? e.message : '삭제 실패');
    } finally {
      setBusy(false);
    }
  };

  const available = getAvailableStock({ stock, reserved_stock: product.reserved_stock });

  return (
    <div style={{ background: '#f0f9ff', padding: 16, borderRadius: 8 }}>
      <Field label="상품명 *">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          disabled={busy}
          style={inputStyle}
        />
      </Field>
      <Field label="상세 설명">
        <RichEditor
          value={description}
          onChange={setDescription}
          uploaderKind="bazaar"
          uploaderOwnerId={product.id}
          disabled={busy}
          minHeight={200}
          placeholder="상품의 상세 설명을 입력하세요."
        />
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
          <button
            type="button"
            onClick={pushDescToNote}
            disabled={busy || pushing}
            title="현재 상품 상세설명 내용을 연결된 검수 메모로 복사합니다."
            style={{
              padding: '6px 12px',
              fontSize: 12,
              fontWeight: 600,
              border: '1px solid #ddd',
              borderRadius: 6,
              background: '#fff',
              color: busy || pushing ? '#bbb' : '#333',
              cursor: busy || pushing ? 'not-allowed' : 'pointer',
            }}
          >
            {pushing ? '반영 중…' : '📥 검수 메모로 보내기'}
          </button>
        </div>
      </Field>
      <Field label="썸네일">
        <ThumbnailUploader
          kind="bazaar"
          ownerId={product.id}
          value={thumbnailUrl}
          onChange={setThumbnailUrl}
          disabled={busy}
        />
      </Field>
      <Field label="상세 이미지">
        <DetailImagesUploader
          kind="bazaar"
          ownerId={product.id}
          values={detailImages}
          onChange={setDetailImages}
          maxCount={5}
          disabled={busy}
        />
      </Field>

      {/* ← [2026-06-23] 태그 — 카테고리 / 브랜드 분리 입력. 사용자 페이지 필터 메뉴로 노출 */}
      <Field label="카테고리 태그 (예: 유아용품, 식품, 저당과자)">
        <TagInput
          value={categoryTags}
          onChange={setCategoryTags}
          disabled={busy}
          kind="category"
          placeholder="카테고리 입력 후 Enter (예: 유아용품, 식품)"
        />
      </Field>
      <Field label="브랜드 태그 (예: 나이키, 샤넬)">
        <TagInput
          value={brandTags}
          onChange={setBrandTags}
          disabled={busy}
          kind="brand"
          placeholder="브랜드 입력 후 Enter (예: 나이키, 샤넬)"
        />
      </Field>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
          gap: 10,
          marginTop: 12,
        }}
      >
        <Field label="가격 (원)">
          <input
            type="number"
            value={price}
            onChange={(e) => setPrice(Number(e.target.value) || 0)}
            disabled={busy}
            step={1000}
            min={0}
            style={inputStyle}
          />
        </Field>
        <Field label={`재고 (개) · 가용 ${available}/${stock}`}>
          <input
            type="number"
            value={stock}
            onChange={(e) => setStock(Number(e.target.value) || 0)}
            disabled={busy}
            step={1}
            min={0}
            style={inputStyle}
          />
        </Field>
        <Field label="상태">
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value as EsgProductStatus)}
            disabled={busy}
            style={inputStyle}
          >
            <option value="on_sale">판매 중</option>
            <option value="sold_out">품절</option>
            <option value="hidden">숨김</option>
          </select>
        </Field>
        <Field label="정렬 순서">
          <input
            type="number"
            value={sortOrder}
            onChange={(e) => setSortOrder(Number(e.target.value) || 0)}
            disabled={busy}
            step={1}
            style={inputStyle}
          />
        </Field>
      </div>

      {/* ← [2026-06-09] 새 상품 라벨 + 세일가 */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
          gap: 10,
          marginTop: 12,
          alignItems: 'end',
        }}
      >
        <Field label="새 상품 라벨">
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, height: 36, fontSize: 13, color: '#333' }}>
            <input type="checkbox" checked={isNew} onChange={(e) => setIsNew(e.target.checked)} disabled={busy} style={{ width: 16, height: 16 }} />
            "새 상품" 뱃지 표시
          </label>
        </Field>
        {/* ← [2026-06-17] 상품 고정 — 체크 시 리스트 맨 앞. 순서는 위 '정렬 순서' 숫자로 결정. */}
        <Field label={`상품 고정 (리스트 맨 앞)${typeof pinnedCount === 'number' ? ` · ${pinnedCount}/8` : ''}`}>
          <label
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              height: 36,
              fontSize: 13,
              color: pinFull ? '#aaa' : '#333',
            }}
            title={pinFull ? '고정은 최대 8개입니다. 다른 상품을 해제하세요.' : undefined}
          >
            <input
              type="checkbox"
              checked={isPinned}
              onChange={(e) => setIsPinned(e.target.checked)}
              disabled={busy || pinFull}                    // ← 8개 찼고 미고정이면 체크 불가
              style={{ width: 16, height: 16 }}
            />
            📌 이 상품을 고정 {pinFull ? '(최대 8개 도달)' : ''}
          </label>
        </Field>
        <Field label="세일가 (원) · 비우면 세일 없음">
          <input
            type="number"
            value={salePrice}
            onChange={(e) => setSalePrice(e.target.value === '' ? '' : (Number(e.target.value) || 0))}
            disabled={busy}
            step={1000}
            min={0}
            placeholder="예: 8000"
            style={inputStyle}
          />
        </Field>
        <Field label="할인율(자동 계산)">
          <div style={{ height: 36, display: 'flex', alignItems: 'center', fontSize: 13, fontWeight: 600, color: discountPct ? '#dc2626' : '#999' }}>
            {salePrice === '' ? '—' : discountPct ? `${discountPct}% 할인 (${(salePrice as number).toLocaleString()}원)` : '세일가가 정상가보다 낮아야 함'}
          </div>
        </Field>
      </div>

      <div style={{ display: 'flex', gap: 6, marginTop: 16 }}>
        <button
          type="button"
          onClick={save}
          disabled={busy}
          style={{
            flex: 1,
            padding: '10px 12px',
            background: busy ? '#ccc' : '#111',
            color: '#fff',
            border: 'none',
            borderRadius: 6,
            cursor: busy ? 'not-allowed' : 'pointer',
            fontSize: 13,
            fontWeight: 600,
          }}
        >
          {busy ? '저장 중…' : '저장'}
        </button>
        <button
          type="button"
          onClick={onCancel}
          disabled={busy}
          style={{
            padding: '10px 16px',
            background: '#fff',
            border: '1px solid #ddd',
            borderRadius: 6,
            cursor: 'pointer',
            fontSize: 13,
          }}
        >
          취소
        </button>
        {showDelete && (
          <button
            type="button"
            onClick={handleDelete}
            disabled={busy}
            style={{
              padding: '10px 16px',
              background: '#fff',
              border: '1px solid #fecaca',
              color: '#dc2626',
              borderRadius: 6,
              cursor: busy ? 'not-allowed' : 'pointer',
              fontSize: 13,
            }}
          >
            🗑 삭제
          </button>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// 공통 UI
// ============================================================================

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '8px 10px',
  border: '1px solid #ddd',
  borderRadius: 4,
  fontSize: 13,
  boxSizing: 'border-box',
};

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: 10 }}>
      <span style={{ fontSize: 12, color: '#666', fontWeight: 600 }}>{label}</span>
      {children}
    </label>
  );
}
